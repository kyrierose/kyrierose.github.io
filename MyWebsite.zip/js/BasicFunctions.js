function onClickEmail(){
	window.location = "index.html#contact";
	document.getElementById('emailContact').value = "akshitdhar@live.com";
}